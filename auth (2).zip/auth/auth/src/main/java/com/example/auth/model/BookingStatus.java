package com.example.auth.model;

public enum BookingStatus {
    PENDING,
    APPROVED,
    REJECTED
}
